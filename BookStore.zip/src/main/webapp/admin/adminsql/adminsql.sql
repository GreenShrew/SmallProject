
SELECT * FROM worker WHERE id='scott';

SELECT COUNT(*) AS membercnt FROM member WHERE useyn='y';
SELECT COUNT(*) AS bookcnt FROM bookproduct WHERE useyn='y';
SELECT COUNT(*) AS ordercnt	FROM orders;
SELECT COUNT(*) AS qnacnt	FROM qna;


SELECT * FROM orders;
SELECT * FROM order_detail;
