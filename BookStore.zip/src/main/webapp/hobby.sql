-- hob : 취미

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image, bestyn) 
values(book_seq.nextVal, '집수리 닥터 강쌤의 셀프 집수리', '2021', 22000, '리스컴', 'hob',
'집수리 백과로, 수업 교재로! 인기 유튜브 ‘강쌤철물’에서 배우는 ‘셀프 집수리’',
'28.jpg', 'y');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, '아빠표 영어 구구단+파닉스 1단-명사', '2018', 11400, '마이클리시', 'hob',
'어린이 영어를 배우려고 파닉스부터 영어 유치원, 영어전집, 영어과외, 영어학원, 영어캠프, 전화영어, 학습지까지 수천만 원을 씁니다. 그렇게 10년을 배워도 틀릴까 봐 조마조마하며 간단한 문장만 말할 수 있었습니다.',
'29.jpg');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image, bestyn) 
values(book_seq.nextVal, '슈퍼 패미컴-퍼펙트 카탈로그', '2020', 22000, '삼호미디어', 'hob',
'슈퍼 패미컴의 하드웨어와 주변기기는 물론 1,447종 소프트웨어를 총 망라한 퍼펙트 가이드.',
'30.jpg', 'y');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, '부의 주인은 누구인가', '2019', 18000, '도솔플러스', 'hob',
'재정자립과 이른 은퇴를 가능하게 하는 9단계 재정자립 프로그램! 빚은 사라지고 더 이상 돈 때문에 일하지 않게 된다!',
'31.jpg');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, '운동 말고 움직임 리셋', '2022', 16000, 'EBSBOOKS', 'hob',
'대한민국 NO. 1 스포츠의학의 전설이 최초로 공개하는 움직임 회복 프로젝트. “제대로 움직여야 통증이 사라진다!”',
'32.jpg');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, 'EBS 당신의 문해력', '2021', 17000, 'EBSBOOKS', 'hob',
'지금 나 자신에게 줄 수 있는 가장 분명한 자산, 부모가 자녀에게 줄 수 있는 가장 큰 선물, 바로 문해력이다!',
'33.jpg');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, '임신 출산 육아 대백과(2021-2022년 개정판)', '20121', 19500, '삼성출판사', 'hob',
'[임신 출산 육아 대백과] 2020년 개정판은 가이드 구성에 충실, 초보엄마들이 궁금해할만한 내용을 사진으로 꼼꼼하게 보여준다.',
'34.jpg');

insert into bookproduct(bseq, bname, byear, price, publisher, genre, content, image) 
values(book_seq.nextVal, 'PC엔진 & PC-FX-퍼펙트 카탈로그', '2020', 20000, '삼호미디어', 'hob',
'메가 드라이브에 이은 두 번째 퍼펙트 카탈로그 PC엔진부터 PC-FX까지 하드웨어와 주변기기는 물론 745종 소프트웨어를 총 망라한 퍼펙트 가이드!',
'35.jpg');